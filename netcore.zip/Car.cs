namespace congestion.calculator
{
    public class Car : Vehicle
    {
        public string GetVehicleType()
        {
            return "Car";
        }
    }
}