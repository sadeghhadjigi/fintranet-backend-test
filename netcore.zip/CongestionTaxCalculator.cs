using System;
using System.Linq;
using congestion.calculator;
public class CongestionTaxCalculator
{
    private readonly ITaxRuleProvider _taxRuleProvider;
    private readonly int _maxDailyFee;

    public CongestionTaxCalculator(ITaxRuleProvider taxRuleProvider, int maxDailyFee = 60)
    {
        _taxRuleProvider = taxRuleProvider;
        _maxDailyFee = maxDailyFee;
    }

    public int GetTax(Vehicle vehicle, DateTime[] dates)
    {
        if (vehicle == null || dates == null || dates.Length == 0) return 0;

        var dailyFee = 0;
        DateTime? lastChargeTime = null;

        var validDates = dates
            .Where(d => d.Year == 2013)
            .OrderBy(d => d)
            .ToArray();

        foreach (var date in validDates)
        {
            if (_taxRuleProvider.IsTollFreeDate(date) || _taxRuleProvider.IsTollFreeVehicle(vehicle))
                continue;

            var fee = _taxRuleProvider.GetTollFee(date, vehicle);

            if (lastChargeTime != null && (date - lastChargeTime.Value).TotalMinutes <= 60)
            {
                dailyFee = dailyFee - _taxRuleProvider.GetTollFee(lastChargeTime.Value, vehicle) + Math.Max(fee, _taxRuleProvider.GetTollFee(lastChargeTime.Value, vehicle));
            }
            else
            {
                dailyFee += fee;
            }

            if (fee > 0)
            {
                lastChargeTime = date;
            }

            if (dailyFee >= _maxDailyFee)
            {
                dailyFee = _maxDailyFee;
                break;
            }
        }

        return dailyFee;
    }
}