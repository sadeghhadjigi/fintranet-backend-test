using System;
using System.Collections.Generic;
using System.Linq;

namespace congestion.calculator
{
    public class GothenburgTaxRuleProvider : ITaxRuleProvider
    {
        private static readonly HashSet<string> TollFreeVehicles = new HashSet<string>
        {
            "Motorcycle", "Tractor", "Emergency", "Diplomat", "Foreign", "Military"
        };

        private static readonly Dictionary<TimeSpan, int> TollFeeSchedule = new Dictionary<TimeSpan, int>
        {
            { new TimeSpan(6, 0, 0), 8 }, { new TimeSpan(6, 30, 0), 13 },
            { new TimeSpan(7, 0, 0), 18 }, { new TimeSpan(8, 0, 0), 13 },
            { new TimeSpan(8, 30, 0), 8 }, { new TimeSpan(15, 0, 0), 13 },
            { new TimeSpan(15, 30, 0), 18 }, { new TimeSpan(17, 0, 0), 13 },
            { new TimeSpan(18, 0, 0), 8 }
        };

        public bool IsTollFreeDate(DateTime date)
        {
            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            var tollFreeDates = new HashSet<DateTime>
            {
                new DateTime(2013, 1, 1),
                new DateTime(2013, 3, 28),
                new DateTime(2013, 3, 29),
                new DateTime(2013, 4, 1),
                new DateTime(2013, 4, 30),
                new DateTime(2013, 5, 1),
                new DateTime(2013, 6, 5),
                new DateTime(2013, 6, 6),
                new DateTime(2013, 6, 21),
                new DateTime(2013, 11, 1),
                new DateTime(2013, 12, 24),
                new DateTime(2013, 12, 25),
                new DateTime(2013, 12, 26),
                new DateTime(2013, 12, 31)
            };

            return tollFreeDates.Contains(date) || date.Month == 7;
        }

        public bool IsTollFreeVehicle(Vehicle vehicle)
        {
            return vehicle != null && TollFreeVehicles.Contains(vehicle.GetVehicleType());
        }

        public int GetTollFee(DateTime date, Vehicle vehicle)
        {
            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            var time = date.TimeOfDay;

            return TollFeeSchedule.Where(t => time >= t.Key).Select(t => t.Value).LastOrDefault();
        }
    }
}