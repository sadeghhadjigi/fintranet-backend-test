using System;

namespace congestion.calculator
{
    public interface ITaxRuleProvider
    {
        bool IsTollFreeDate(DateTime date);
        bool IsTollFreeVehicle(Vehicle vehicle);
        int GetTollFee(DateTime date, Vehicle vehicle);
    }
}