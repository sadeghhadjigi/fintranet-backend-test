namespace congestion.calculator
{
    public interface Vehicle
    {
        string GetVehicleType();
    }
}